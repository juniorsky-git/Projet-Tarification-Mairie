# Plan d'Implmentation : Dashboard Financier Multi-Ples

L'objectif est de gnraliser l'application pour qu'elle puisse calculer le taux de couverture de n'importe quel service municipal (ple) en utilisant la grille tarifaire complte fournie par l'utilisateur.

## Phase 1 : Refonte des Structures de Donnes

### [Component Name] Modle de Tarification

#### [MODIFY] [Tarif.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/src/fr/mairie/tarification/Tarif.java)
- Remplacer les champs fixes (`repas`, `garde`) par une `Map<String, Double> prix`.
- Adapter le constructeur pour accepter cette Map.
- Mettre  jour les mthodes `getRepas()` etc. pour qu'elles cherchent dans la Map via une cl.

#### [MODIFY] [DonneesTarifs.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/src/fr/mairie/tarification/DonneesTarifs.java)
- Ajouter des constantes `String` pour chaque service (`REPAS`, `ACCUEIL_JOURNEE`, `ADOS_VAC_JOURNEE_REPAS`, ...).
- Implmenter la mthode `chargerTarifsReference` fournie par l'utilisateur avec la grille complte.
- Crer une mthode utilitaire `map()` pour simplifier l'ajout des tarifs dans la liste.

## Phase 2 : Gnralisation du Moteur de Calcul

### [Component Name] Moteur de Calcul Gnrique

#### [MODIFY] [Calculateur.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/src/fr/mairie/tarification/Calculateur.java)
- Crer un objet (ou Enum/Map) de configuration par Ple. 
    - Exemple : Ple ADOS -> Antenne "ESPACE ADOS", Mot-cl Dataviz "ESPACE ADOS", Cl Tarif "ADOS_VAC_...".
- Transformer `calculerTotalDepenses` pour accepter des filtres dynamiques par antenna ET par libell (ex: ne pas inclure "LOISIRS" quand on calcule "ADOS").
- Transformer `chargerEffectifsParTranche` pour pouvoir démarrer à une ligne spécifique dans Dataviz (puisque chaque pôle a son propre tableau vertical).

## Phase 3 : Interface Utilisateur Multi-Ples

### [Component Name] Dashboard de Synthse

#### [MODIFY] [Main.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/src/fr/mairie/tarification/Main.java)
- Ajouter une option [5] "Synthse multi-services".
- Lancer le calcul pour chaque ple configur et afficher un tableau rcapitulatif :
    - Ple | Dpenses | Recettes | Taux de Couverture
    - Scolaire | ... | ... | ...
    - Ados | ... | ... | ...
    - etc.

## Open Questions

> [!IMPORTANT]
> **Source des volumes pour les ples non-scolaires**
> Pour les Ados et le Priscolaire, je ne vois pas de rpartition A, B, C... dans le fichier `Feuille_dataviz.xlsx`. 
> - **Option A** : Vous avez un autre fichier avec ces chiffres ?
> - **Option B** : Je dois utiliser une répartition moyenne (hypothèse de répartition identique à la cantine) ?
> - **Option C** : Nous n'affichons que les Dépenses (Audit) pour ces pôles en attendant d'avoir les données ?

## Verification Plan

### Automated Tests
- Lancement de `build.ps1` pour vrifier le nouveau Dashboard.
- Comparaison des totaux avec les sommes manuelles dans Excel.

### Manual Verification
- Vrifier que le tarif Michigan (Scolaire) reste inchang aprs la refonte.
