# Plan d'implémentation : Bornes, Structure et IHM

## 1. Tests des limites QF (Transitions de tranches)
Dans `TestCasReels.java`, je vais ajouter des tests pour "stresser" les frontières des quotients familiaux, car c'est là que les bugs de bornes (ex: `<` vs `<=`) se cachent souvent.

**Tests prévus (autour de 3954, seuil entre G et F) :**
- `3953.99` -> Attente : **Tranche G**
- `3954.00` -> Attente : **Tranche F**
- `3954.01` -> Attente : **Tranche F**

**Analyse nécessaire** : Actuellement, le fichier Excel donne des tranches avec des entiers (ex: `G <= 3953` et `F de 3954 à 6240`). Le code lit ces entiers et fait un strict `qf < qfMax`. Il faudra s'assurer qu'un QF avec décimales ne tombe pas dans le vide entre deux tranches (ex: QF = 3953.5).

## 2. Validation exhaustive de la structure Excel
Dans `DonneesTarifs.chargerGrilleStandard()`, je vais implémenter des gardes robustes pour éviter au moteur de traiter des fichiers "vides" mais valides formellement :
- `if (workbook.getNumberOfSheets() == 0)` -> Erreur.
- `if (s.getLastRowNum() < 5)` -> Erreur (grille trop courte).
- `if (mapping.size() < 5)` -> Erreur (En-têtes non détectés, ce n'est pas la bonne grille tarifaire).

Cela lèvera une exception spécifique (`IllegalArgumentException` par exemple) attrapable par l'interface.

## 3. Nettoyage et Encapsulation UI
Dans `ConsoleUI.java`, la méthode `consulterTarif` sera purgée de toute empreinte technique.
```java
// Au lieu d'afficher l'exception brute, on traduira :
catch (FileNotFoundException e) {
    System.out.println("ERREUR : Fichier introuvable.");
} catch (IllegalArgumentException e) {
    System.out.println("ERREUR : Structure de la grille tarifaire invalide. Veuillez importer le bon document.");
}
```

Les détails techniques (`e.getMessage()`) iront dans `LogService`.

## User Review Required
Êtes-vous d'accord avec cette approche pour sécuriser les limites de tranches et encapsuler totalement les erreurs côté utilisateur ? Si oui, je lance le codage, les tests, et je documente vos réflexions dans le `.md`.
