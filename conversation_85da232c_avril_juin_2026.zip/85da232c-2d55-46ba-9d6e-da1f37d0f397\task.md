# Suivi des Tâches : Validation Avancée & UI

## Phase 5 : Tests des Bornes (Transitions QF)
- `[x]` Définir les tests aux transitions (ex: 3953.99, 3954.0, 3954.01).
- `[x]` Définir une règle métier claire pour la continuité (`qf >= min && qf < max` avec des bornes jointives, ex: G fini à 3954, F commence à 3954).
- `[x]` Corriger `DonneesTarifs.java` pour appliquer cette règle métier et éviter les "trous" (trous décimaux).

## Phase 6 : Validation Structurelle du Fichier Excel
- `[x]` Vérifier `wb.getNumberOfSheets() == 0`.
- `[x]` Vérifier `s.getLastRowNum() < 5`.
- `[x]` Vérifier la présence obligatoire de pépites de la mairie (ex: la colonne REPAS doit obligatoirement être trouvée).
- `[x]` Lever des `IllegalArgumentException` pour rejeter les tables non-conformes.

## Phase 7 : Encapsulation UI (ConsoleUI)
- `[x]` Intercepter `IllegalArgumentException` dans `chargerFichierTarifs` pour afficher "Structure de la grille invalide".
- `[x]` S'assurer qu'aucune trace technique n'est affichée dans la console pour l'utilisateur fina.

## Phase 8 : Archivage
- `[x]` Rédiger le rapport technique dans `journal_developpement.md`.
- `[x]` Git Commit & Push.
