# Suivi : Installation Environnement Système

- [x] Installation Ubuntu (WSL 2) - *Fait manuellement par l'utilisateur*
- [/] Installation PostgreSQL (via Chocolatey)
- [ ] Installation Node.js LTS (via Chocolatey)
- [ ] Installation JDK Temurin 21 (via Chocolatey)
- [ ] Vérification finale de l'environnement
