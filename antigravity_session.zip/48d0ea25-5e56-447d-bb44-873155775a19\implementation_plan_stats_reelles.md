# Rendre le Dashboard "Réel" et Dynamique

Actuellement, les chiffres du Dashboard (1248 simulations, 6 fichiers, etc.) sont des textes fixes issus de la maquette. Ce plan vise à les connecter aux véritables compteurs de l'application.

## User Review Required

> [!NOTE]
> Les compteurs (Simulations, Consultations) seront réinitialisés à chaque redémarrage du serveur car ils sont stockés en mémoire (RAM) pour le moment. Une persistence en base de données pourra être ajoutée plus tard.

## Proposed Changes

### Backend (Java)

#### [NEW] [StatsService.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/tarification-api/src/main/java/fr/mairie/tarification_api/StatsService.java)
- Classe singleton pour gérer les compteurs :
    - `nombreSimulations` (incrémenté à chaque recherche QF).
    - `nombreFichiersImportes` (incrémenté à chaque upload réussi).
    - `nombreConsultations` (incrémenté à chaque affichage de la grille complète).

#### [NEW] [StatsController.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/tarification-api/src/main/java/fr/mairie/tarification_api/StatsController.java)
- Endpoint `GET /api/stats` renvoyant un objet JSON avec :
    - Les 3 compteurs ci-dessus.
    - Le nombre de tranches de la grille actuelle (`grilleCourante.size()`).

#### [MODIFY] [TarifController.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/tarification-api/src/main/java/fr/mairie/tarification_api/TarifController.java)
- Appel à `StatsService.incrementerSimulations()` dans la méthode `getTarif`.
- Appel à `StatsService.incrementerFichiers()` dans la méthode `upload`.

### Frontend (JavaScript)

#### [MODIFY] [index.html](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/tarification-api/src/main/resources/static/index.html)
- Mise à jour de la fonction `chargerDashboardData()` :
    - Appel à `/api/stats`.
    - Injection des chiffres réels dans les éléments `stat-simulations`, `stat-fichiers`, `stat-consultations` et `stat-tranches`.

## Verification Plan

### Automated Tests
- `curl http://localhost:8080/api/stats` pour vérifier les valeurs initiales (0).
- Effectuer une recherche QF, puis vérifier que `api/stats` renvoie bien `simulations: 1`.

### Manual Verification
- Ouvrir le Dashboard.
- Aller dans "Consultation", faire une recherche.
- Revenir sur le Dashboard : le chiffre des simulations doit avoir augmenté en temps réel.
