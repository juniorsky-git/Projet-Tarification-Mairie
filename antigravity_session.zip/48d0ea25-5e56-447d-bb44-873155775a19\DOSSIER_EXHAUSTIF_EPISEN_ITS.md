# 📚 Dossier Exhaustif : Maîtriser le programme EPISEN ITS

Ce dossier compile les points critiques à aborder pour prouver ta connaissance parfaite de l'école.

---

## 1. Structure Pédagogique (Le triple profil)
L'EPISEN ITS ne cherche pas des "codeurs purs", mais des profils hybrides :
1. **Pôle Informatique (Back-office)** : Architecture réseaux, Sécurité, Cloud computing, Développement (C++, Java).
2. **Pôle Électronique (Front-office)** : Objets connectés (IoT), Systèmes embarqués, Capteurs biomédicaux.
3. **Pôle Médical (Contenu)** : Anatomie, Signaux biologiques, Télémédecine, Imagerie médicale.

---

## 2. Le Big Data Santé à l'EPISEN
Puisque c'est ton objectif (Data Analyst), mentionne ces éléments :
- **Stockage et analyse de masse** : Comment gérer des millions de dossiers patients.
- **Intelligence Artificielle** : Algorithmes d'aide au diagnostic clinique.
- **Interopérabilité** : Faire en sorte que le logiciel d'un médecin puisse parler au logiciel d'un hôpital (Normes HL7/DICOM).

---

## 3. Réglementation : Ton lien avec le Droit-Éco
Le monde de la santé est très surveillé. Tu dois montrer que tu le sais :
- **RGPD & HDS** : Protection stricte de la vie privée.
- **Certification des Dispositifs Médicaux** : Un logiciel de santé est considéré comme un "dispositif médical" et doit suivre des règles de sécurité industrielles strictes.

---

## 4. Les Valeurs de l'École (Ce que tu partages)
- **L'Apprentissage** : L'école valorise l'immersion en entreprise (parfait pour ton côté "terrain" mairie + AES).
- **L'Éthique** : Mettre la technologie au service de l'humain et du patient.
- **L'International** : Mobilité obligatoire d'au moins 3 mois.

---

## 📌 Top 5 des mots-clés "Expert" à placer :
1. **HDS** (Hébergeur de Données de Santé) : "Je sais que la sécurité des données est au cœur du cursus ITS."
2. **e-Santé / Santé connectée** : Le domaine global de l'école.
3. **Interopérabilité** : La capacité des systèmes à communiquer entre eux.
4. **Data Analytics** : Ton futur métier, très présent dans les modules de 3ème année.
5. **Ingénieur Citoyen** : Un terme souvent apprécié qui montre ton envie d'être utile à la société (lien avec AES).
