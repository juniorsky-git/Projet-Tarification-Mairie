# 🏥 Préparation Entretien : EPISEN - Technologies pour la Santé (ITS)

**Profil :** Séri-khane YOLOU (BUT 2 Informatique)
**Objectif :** Admission Cycle Ingénieur ITS

---

## 📝 1. Les Points Clés de la Formation (À connaître par cœur)
- **Label CTI & EUR-ACE** : C'est un diplôme d'ingénieur public reconnu partout en Europe.
- **La Triple Compétence** : 
    1. **Informatique/Logiciel** (ton BUT).
    2. **Électronique/Réseaux** (objets connectés, IoT).
    3. **Médical** (télémédecine, dispositifs médicaux).
- **L'Alternance** : Rythme 1 semaine / 1 semaine sur 3 ans. Indispensable pour ton profil pro.
- **Missions Étrangères** : Séjour international obligatoire (très important pour le diplôme).

---

## 🎯 2. Pourquoi ton profil est parfait pour ITS ?
- **Ton Atout AES** : Tu comprends déjà la réalité du soin et du handicap. Tu parles le "langage" des médecins et soignants.
- **Ton Stage Mairie** : Tu travailles déjà sur la gestion de données (Data) et le support, ce qui prouve ta polyvalence.
- **Ton Projet Pro** : Tu veux devenir Data Analyst en Santé. La formation ITS propose des modules de **Big Data** et **Intelligence Artificielle** parfaitement alignés.

---

## 🗣 3. Questions stratégiques à poser au Jury
1. *"Quels types d'entreprises accueillent majoritairement vos apprentis ITS ? (Éditeurs de logiciels santé, hôpitaux, start-up de dispositifs médicaux ?)"*
2. *"Quelle est la part des enseignements assurée par des professionnels du secteur médical (médecins, ingénieurs biomédicaux) ?"*
3. *"Y a-t-il des passerelles possibles avec les laboratoires de recherche de l'UPEC pour ceux qui souhaitent creuser l'IA en Santé ?"*

---

## ⚡ 4. Ta Phrase de Conclusion (À mémoriser)
*"Ma force est de ne pas choisir entre l'humain et la technique. L'EPISEN ITS me permet de mettre mes compétences informatiques au service de mon engagement pour la santé, avec une vision terrain que j'ai acquise en tant qu'AES."*
