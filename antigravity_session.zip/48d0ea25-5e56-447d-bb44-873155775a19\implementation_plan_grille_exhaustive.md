# [Issue #5] Affichage exhaustif des tarifs dans l'interface web

L'objectif est de permettre aux utilisateurs de consulter l'intégralité de la grille tarifaire (par tranche et par service) directement depuis l'interface web, comme c'était le cas dans la version console du logiciel.

## Proposed Changes

### Backend (API)

#### [MODIFY] [TarifController.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/tarification-api/src/main/java/fr/mairie/tarification_api/TarifController.java)
- Ajout d'un endpoint `GET /api/tarifs/complet` qui renvoie la liste `grilleCourante`.

### Frontend (User Interface)

#### [MODIFY] [index.html](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/tarification-api/src/main/resources/static/index.html)
- Ajout d'un bouton "Afficher toute la grille" pour charger les données.
- Ajout d'une section `<div id="grilleCompleteContainer">` contenant un tableau HTML (`<table>`) structuré.
- Les colonnes du tableau regrouperont les services par catégories (Restauration, Loisirs, Périscolaire, Études, Ados, Séjours).
- Ajout d'une fonction JavaScript `chargerGrilleComplete()` pour effectuer l'appel API et générer le DOM.
- Amélioration du CSS pour rendre le tableau lisible (bordures fines, couleurs alternées pour les lignes, mise en évidence des en-têtes).

## Verification Plan

### Automated Tests
- Lancement de `mvn clean compile` pour valider le nouveau endpoint.
- Vérification de l'endpoint via `curl http://localhost:8080/api/tarifs/complet`.

### Manual Verification
- Ouvrir le navigateur sur `http://localhost:8080`.
- Cliquer sur le nouveau bouton "Afficher toute la grille".
- Vérifier que toutes les tranches (A à G, EXT si présente) s'affichent avec les bons tarifs pour chaque colonne.
- Vérifier la mise à jour dynamique du tableau lors du chargement d'un nouveau fichier Excel.
