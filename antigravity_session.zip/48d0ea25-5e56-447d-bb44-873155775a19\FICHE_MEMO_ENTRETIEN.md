# 📋 Fiche Mémo : Entretien Séri-khane YOLOU

**Objectif :** Entretien de 20 minutes (BUT 2 Informatique)
**Poste actuel :** Stagiaire Data & IA - Mairie de Crosne

---

## 🚀 1. Le Pitch "30 secondes"
"Je suis en BUT 2 Informatique à Fontainebleau. Actuellement en stage à la mairie de Grosne, je développe un outil d'automatisation financière en **Java**. Mon parcours est marqué par une expérience de 3 mois comme **AES** dans le milieu du handicap, ce qui m'a donné une vision très humaine de l'informatique. Mon objectif est de devenir **Data Analyst pour le secteur de la Santé**."

---

## 🛠 2. Points Techniques Clés (Le "Blindage")
- **Technologies** : Java 21, Apache POI (Excel), PDFBox (Reporting).
- **Programmation Défensive** : "J'ai apporté un soin particulier au **blindage** du code pour qu'il gère les données manquantes ou erronées sans jamais planter."
- **Automatisation** : Transformation d'un processus manuel complexe (Excel) en un rapport PDF généré en **un seul clic**.

---

## 🤝 3. Expérience AES (Ton Atout Humain)
- **Compétences** : Patience, écoute active, vulgarisation technique.
- **Message** : "Mon passé d'AES me permet de mieux comprendre les besoins des utilisateurs non-techniques et de concevoir des outils vraiment adaptés au terrain."

---

## 🎯 4. Vision Professionnelle (Le Futur)
- **Domaine** : Data & Santé.
- **Motivation** : "L'essor du **Big Data dans la santé** est un sujet qui me passionne, comme j'ai pu l'étudier en cours de droit-économie. Je veux lier ma connaissance du milieu médical à mes compétences en analyse de données."

---

## ⚓ 5. L'Anecdote "Dépannage" (Preuve de réactivité)
- **Le fait** : Diagnostic et résolution d'un problème Outlook pour la Police Municipale.
- **La cause** : Un "Add-in" défectueux bloquait le lancement.
- **La leçon** : Analyse méthodique d'un bug système.

---

> [!TIP]
> **Conseil de dernière minute** : Sourie, parle calmement, et si tu ne sais pas répondre à une question technique, dis franchement : *"C'est un point que je n'ai pas encore approfondi, mais je sais où chercher la documentation pour l'apprendre."* C'est une réponse de pro.
