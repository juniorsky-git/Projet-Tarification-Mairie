# Transformation vers le Dashboard Premium "Mairie Tarification"

Ce plan vise à métamorphoser l'interface actuelle en une application web moderne et haut de gamme, fidèle aux maquettes cibles, tout en intégrant les fonctionnalités de consultation exhaustive demandées (Issue #5).

## User Review Required

> [!IMPORTANT]
> Cette refonte est une transformation majeure de l'interface utilisateur. L'ancien design minimaliste sera remplacé par une structure à barre latérale (Sidebar) avec plusieurs vues (Tableau de bord, Consultation, Simulation, etc.).

## Proposed Changes

### 1. Backend (API)

#### [MODIFY] [TarifController.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/tarification-api/src/main/java/fr/mairie/tarification_api/TarifController.java)
- Ajout de l'endpoint `GET /api/tarifs/complet` pour renvoyer l'intégralité de la grille en cours.

---

### 2. Frontend (Design System & Structure)

#### [NEW] [style.css](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/tarification-api/src/main/resources/static/style.css)
- Création d'un système de design complet :
    - **Palette** : Indigo/Violet pour le primaire, Dark Blue pour la sidebar, Slate pour les textes.
    - **Variables CSS** : Pour une maintenance facile des couleurs et ombres portées.
    - **Glassmorphism** : Effets de transparence et de flou sur les cartes.
    - **Typographie** : Importation de la police "Inter" (Google Fonts).

#### [MODIFY] [index.html](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/tarification-api/src/main/resources/static/index.html)
- Refonte complète de la structure DOM :
    - **Sidebar** : Menu de navigation à gauche avec icônes.
    - **Main Area** : Zone de contenu dynamique qui change selon la vue sélectionnée.

---

### 3. Logique Applicative (JavaScript)

#### [MODIFY] [index.html](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/tarification-api/src/main/resources/static/index.html) (Section Script)
- **Gestionnaire de Vues** : Logique pour basculer entre `Dashboard`, `Consultation`, `Simulation` et `Grilles`.
- **Vue Consultation** : Refonte de la recherche par QF pour afficher les résultats sous forme de cartes élégantes avec icônes (Restauration, Loisirs, etc.).
- **Vue Simulation (Issue #5)** : Affichage de la grille exhaustive sous forme de tableau riche, structuré comme dans la maquette (Tranches de A à G | Prix facturé | etc.).
- **Vue Dashboard** : Agrégation des données de `DonneesBudgetaires` pour afficher les indicateurs clès (+1000 simulations, Tranches QF, etc.).

## Verification Plan

### Automated Tests
- `mvn clean compile` pour valider l'API.
- Test de rendu multi-résolution (Desktop/Tablette) via les outils développeur du navigateur.

### Manual Verification
- Naviguer entre les différents onglets de la barre latérale.
- Tester la recherche par QF et admirer le rendu sous forme de cartes.
- Tester l'affichage de la grille complète dans l'onglet "Simulation financière".
- Téléverser un nouveau fichier Excel et vérifier que toutes les vues (Consultation et Simulation) se mettent à jour.
