Title: Diplôme d’ingénieur Technologies pour la Santé <Br> en formation initiale sous statut d'étudiant et d'apprenti<Br>N° RNCP 41527 - EPISEN

Source: https://episen.u-pec.fr/formations/technologies-pour-la-sante-its

---

[Aller au contenu](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#contenu-encadres) | [Navigation](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#menu_principal) | [Accès directs](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#acces_directs) | [Connexion](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#connexion)
[Université Paris-Est Créteil](https://www.u-pec.fr/)
- [[Présentation](https://episen.u-pec.fr/presentation)](https://episen.u-pec.fr/presentation)Présentation
































                                Présentation




                    [L'école](https://episen.u-pec.fr/presentation/l-ecole)
















[Direction](https://episen.u-pec.fr/presentation/direction)
















[Qualité](https://episen.u-pec.fr/presentation/processus-qualite)
















[Plan d'accès](https://episen.u-pec.fr/presentation/plan-d-acces)
















[Contacts](https://episen.u-pec.fr/presentation/contacts)




















- [L'école](https://episen.u-pec.fr/presentation/l-ecole)

















- [Direction](https://episen.u-pec.fr/presentation/direction)

















- [Qualité](https://episen.u-pec.fr/presentation/processus-qualite)

















- [Plan d'accès](https://episen.u-pec.fr/presentation/plan-d-acces)

















- [Contacts](https://episen.u-pec.fr/presentation/contacts)

















- [[Formations](https://episen.u-pec.fr/formations)](https://episen.u-pec.fr/formations)Formations
































                                Formations




                    [Génie biomédical et santé (ISBS)](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs)



























                    [[Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-classique)](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-classique)[[Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-en-apprentissage)](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-en-apprentissage)


[Technologies pour la Santé (ITS) - sous statut d'étudiant et d'apprenti](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)
















[Systèmes d’Information (SI)](https://episen.u-pec.fr/formations/systemes-d-information-si)



























                    Formation initiale sous statut d'étudiantFormation initiale sous statut d'apprenti


[Apprentissage](https://episen.u-pec.fr/formations/apprentissage)




















- [Génie biomédical et santé (ISBS)](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs)



























                    [Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-classique)[Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-en-apprentissage)



- [Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-classique)
- [Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-en-apprentissage)
- [Technologies pour la Santé (ITS) - sous statut d'étudiant et d'apprenti](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

















- [Systèmes d’Information (SI)](https://episen.u-pec.fr/formations/systemes-d-information-si)



























                    [Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-classique)[Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-en-apprentissage)



- [Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-classique)
- [Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-en-apprentissage)
- [Apprentissage](https://episen.u-pec.fr/formations/apprentissage)

















- [[Admissions](https://episen.u-pec.fr/admissions)](https://episen.u-pec.fr/admissions)Admissions
































                                Admissions

[Candidater en cycle ingénieur](https://episen.u-pec.fr/admissions/candidater-en-cycle-ingenieur)




















- [Candidater en cycle ingénieur](https://episen.u-pec.fr/admissions/candidater-en-cycle-ingenieur)

















- [[Professionnels](https://episen.u-pec.fr/entreprises)](https://episen.u-pec.fr/entreprises)Professionnels
































                                Professionnels




                    [TAXE D'APPRENTISSAGE](https://episen.u-pec.fr/entreprises/taxe-d-apprentissage)
















[RECRUTEZ VOS STAGIAIRES, APPRENTIS ET FUTURS COLLABORATEURS](https://episen.u-pec.fr/entreprises/proposez-une-offre-de-stage-d-alternance-ou-d-emploi)
















[RÉSEAU DES ALUMNI](https://episen.u-pec.fr/entreprises/alumni)




















- [TAXE D'APPRENTISSAGE](https://episen.u-pec.fr/entreprises/taxe-d-apprentissage)

















- [RECRUTEZ VOS STAGIAIRES, APPRENTIS ET FUTURS COLLABORATEURS](https://episen.u-pec.fr/entreprises/proposez-une-offre-de-stage-d-alternance-ou-d-emploi)

















- [RÉSEAU DES ALUMNI](https://episen.u-pec.fr/entreprises/alumni)

















- [[Vie étudiante](https://episen.u-pec.fr/vie-etudiante)](https://episen.u-pec.fr/vie-etudiante)Vie étudiante
































                                Vie étudiante




                    [Associations étudiantes](https://episen.u-pec.fr/vie-etudiante/associations-etudiantes)
















[Services numériques](https://episen.u-pec.fr/vie-etudiante/services-numeriques)
















[Restauration](https://episen.u-pec.fr/vie-etudiante/restauration)
















[Bourses et allocations](https://episen.u-pec.fr/vie-etudiante/bourses-et-allocations)
















[Jobs](https://episen.u-pec.fr/vie-etudiante/jobs)
















[Logement](https://episen.u-pec.fr/vie-etudiante/logement)
















[Logements destinés aux apprentis à Créteil Université](https://episen.u-pec.fr/vie-etudiante/logements-destines-aux-apprentis-a-creteil-universite)
















[Sport](https://episen.u-pec.fr/vie-etudiante/sport)
















[Bibliothèques](https://episen.u-pec.fr/vie-etudiante/bibliotheques)




















- [Associations étudiantes](https://episen.u-pec.fr/vie-etudiante/associations-etudiantes)

















- [Services numériques](https://episen.u-pec.fr/vie-etudiante/services-numeriques)

















- [Restauration](https://episen.u-pec.fr/vie-etudiante/restauration)

















- [Bourses et allocations](https://episen.u-pec.fr/vie-etudiante/bourses-et-allocations)

















- [Jobs](https://episen.u-pec.fr/vie-etudiante/jobs)

















- [Logement](https://episen.u-pec.fr/vie-etudiante/logement)

















- [Logements destinés aux apprentis à Créteil Université](https://episen.u-pec.fr/vie-etudiante/logements-destines-aux-apprentis-a-creteil-universite)

















- [Sport](https://episen.u-pec.fr/vie-etudiante/sport)

















- [Bibliothèques](https://episen.u-pec.fr/vie-etudiante/bibliotheques)

















- [Scolarité](https://episen.u-pec.fr/scolarite)

















[Présentation](https://episen.u-pec.fr/presentation)
[Présentation](https://episen.u-pec.fr/presentation)
- [L'école](https://episen.u-pec.fr/presentation/l-ecole)

















- [Direction](https://episen.u-pec.fr/presentation/direction)

















- [Qualité](https://episen.u-pec.fr/presentation/processus-qualite)

















- [Plan d'accès](https://episen.u-pec.fr/presentation/plan-d-acces)

















- [Contacts](https://episen.u-pec.fr/presentation/contacts)

















[L'école](https://episen.u-pec.fr/presentation/l-ecole)
[Direction](https://episen.u-pec.fr/presentation/direction)
[Qualité](https://episen.u-pec.fr/presentation/processus-qualite)
[Plan d'accès](https://episen.u-pec.fr/presentation/plan-d-acces)
[Contacts](https://episen.u-pec.fr/presentation/contacts)
[Formations](https://episen.u-pec.fr/formations)
[Formations](https://episen.u-pec.fr/formations)
- [Génie biomédical et santé (ISBS)](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs)

[Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-classique)[Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-en-apprentissage)



- [Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-classique)
- [Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-en-apprentissage)
- [Technologies pour la Santé (ITS) - sous statut d'étudiant et d'apprenti](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

















- [Systèmes d’Information (SI)](https://episen.u-pec.fr/formations/systemes-d-information-si)



























                    [Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-classique)[Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-en-apprentissage)



- [Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-classique)
- [Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-en-apprentissage)
- [Apprentissage](https://episen.u-pec.fr/formations/apprentissage)

















[Génie biomédical et santé (ISBS)](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs)
- [Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-classique)
- [Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-en-apprentissage)
[Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-classique)
[Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs/formation-en-apprentissage)
[Technologies pour la Santé (ITS) - sous statut d'étudiant et d'apprenti](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)
[Systèmes d’Information (SI)](https://episen.u-pec.fr/formations/systemes-d-information-si)
- [Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-classique)
- [Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-en-apprentissage)
[Formation initiale sous statut d'étudiant](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-classique)
[Formation initiale sous statut d'apprenti](https://episen.u-pec.fr/formations/systemes-d-information-si/formation-en-apprentissage)
[Apprentissage](https://episen.u-pec.fr/formations/apprentissage)
[Admissions](https://episen.u-pec.fr/admissions)
[Admissions](https://episen.u-pec.fr/admissions)
- [Candidater en cycle ingénieur](https://episen.u-pec.fr/admissions/candidater-en-cycle-ingenieur)

















[Candidater en cycle ingénieur](https://episen.u-pec.fr/admissions/candidater-en-cycle-ingenieur)
[Professionnels](https://episen.u-pec.fr/entreprises)
[Professionnels](https://episen.u-pec.fr/entreprises)
- [TAXE D'APPRENTISSAGE](https://episen.u-pec.fr/entreprises/taxe-d-apprentissage)

















- [RECRUTEZ VOS STAGIAIRES, APPRENTIS ET FUTURS COLLABORATEURS](https://episen.u-pec.fr/entreprises/proposez-une-offre-de-stage-d-alternance-ou-d-emploi)

















- [RÉSEAU DES ALUMNI](https://episen.u-pec.fr/entreprises/alumni)

















[TAXE D'APPRENTISSAGE](https://episen.u-pec.fr/entreprises/taxe-d-apprentissage)
[RECRUTEZ VOS STAGIAIRES, APPRENTIS ET FUTURS COLLABORATEURS](https://episen.u-pec.fr/entreprises/proposez-une-offre-de-stage-d-alternance-ou-d-emploi)
[RÉSEAU DES ALUMNI](https://episen.u-pec.fr/entreprises/alumni)
[Vie étudiante](https://episen.u-pec.fr/vie-etudiante)
[Vie étudiante](https://episen.u-pec.fr/vie-etudiante)
- [Associations étudiantes](https://episen.u-pec.fr/vie-etudiante/associations-etudiantes)

















- [Services numériques](https://episen.u-pec.fr/vie-etudiante/services-numeriques)

















- [Restauration](https://episen.u-pec.fr/vie-etudiante/restauration)

















- [Bourses et allocations](https://episen.u-pec.fr/vie-etudiante/bourses-et-allocations)

- [Jobs](https://episen.u-pec.fr/vie-etudiante/jobs)

















- [Logement](https://episen.u-pec.fr/vie-etudiante/logement)

















- [Logements destinés aux apprentis à Créteil Université](https://episen.u-pec.fr/vie-etudiante/logements-destines-aux-apprentis-a-creteil-universite)

















- [Sport](https://episen.u-pec.fr/vie-etudiante/sport)

















- [Bibliothèques](https://episen.u-pec.fr/vie-etudiante/bibliotheques)

















[Associations étudiantes](https://episen.u-pec.fr/vie-etudiante/associations-etudiantes)
[Services numériques](https://episen.u-pec.fr/vie-etudiante/services-numeriques)
[Restauration](https://episen.u-pec.fr/vie-etudiante/restauration)
[Bourses et allocations](https://episen.u-pec.fr/vie-etudiante/bourses-et-allocations)
[Jobs](https://episen.u-pec.fr/vie-etudiante/jobs)
[Logement](https://episen.u-pec.fr/vie-etudiante/logement)
[Logements destinés aux apprentis à Créteil Université](https://episen.u-pec.fr/vie-etudiante/logements-destines-aux-apprentis-a-creteil-universite)
[Sport](https://episen.u-pec.fr/vie-etudiante/sport)
[Bibliothèques](https://episen.u-pec.fr/vie-etudiante/bibliotheques)
[Scolarité](https://episen.u-pec.fr/scolarite)
[www.u-pec.fr](http://www.u-pec.fr)
- 
        Imprimer

- [Télécharger en PDF](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its?toPdf=true)
- 
        Partager

            Partager cette page

                    [Envoyer par email](https://episen.u-pec.fr/servlet/com.jsbsoft.jtf.core.SG?PROC=TRAITEMENT_ENVOI_AMI_FRONT&ACTION=ENVOYER&CODE=1457380695866&OBJET=article)

                        [Facebook](https://www.facebook.com/sharer/sharer.php?s=100&u=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

                        [X (Twitter)](https://twitter.com/intent/tweet?url=https%3A%2F%2Fepisen.u-pec.fr%2Fformations%2Ftechnologies-pour-la-sante-its&text=Dipl%C3%B4me+d%E2%80%99ing%C3%A9nieur+Technologies+pour+la+Sant%C3%A9+...)

                        [Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)



- 
                    [Envoyer par email](https://episen.u-pec.fr/servlet/com.jsbsoft.jtf.core.SG?PROC=TRAITEMENT_ENVOI_AMI_FRONT&ACTION=ENVOYER&CODE=1457380695866&OBJET=article)

- 
                        [Facebook](https://www.facebook.com/sharer/sharer.php?s=100&u=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

- 
                        [X (Twitter)](https://twitter.com/intent/tweet?url=https%3A%2F%2Fepisen.u-pec.fr%2Fformations%2Ftechnologies-pour-la-sante-its&text=Dipl%C3%B4me+d%E2%80%99ing%C3%A9nieur+Technologies+pour+la+Sant%C3%A9+...)

- 
                        [Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

- [Télécharger en PDF](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its?toPdf=true)
[Télécharger en PDF](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its?toPdf=true)
- 
                    [Envoyer par email](https://episen.u-pec.fr/servlet/com.jsbsoft.jtf.core.SG?PROC=TRAITEMENT_ENVOI_AMI_FRONT&ACTION=ENVOYER&CODE=1457380695866&OBJET=article)

- 
                        [Facebook](https://www.facebook.com/sharer/sharer.php?s=100&u=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

- 
                        [X (Twitter)](https://twitter.com/intent/tweet?url=https%3A%2F%2Fepisen.u-pec.fr%2Fformations%2Ftechnologies-pour-la-sante-its&text=Dipl%C3%B4me+d%E2%80%99ing%C3%A9nieur+Technologies+pour+la+Sant%C3%A9+...)

- 
                        [Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

[Envoyer par email](https://episen.u-pec.fr/servlet/com.jsbsoft.jtf.core.SG?PROC=TRAITEMENT_ENVOI_AMI_FRONT&ACTION=ENVOYER&CODE=1457380695866&OBJET=article)
[Facebook](https://www.facebook.com/sharer/sharer.php?s=100&u=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)
[X (Twitter)](https://twitter.com/intent/tweet?url=https%3A%2F%2Fepisen.u-pec.fr%2Fformations%2Ftechnologies-pour-la-sante-its&text=Dipl%C3%B4me+d%E2%80%99ing%C3%A9nieur+Technologies+pour+la+Sant%C3%A9+...)
[Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

[Télécharger en PDF](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its?toPdf=true)
Vous êtes ici :
- 





                        Accueil FR







                        ›


- 

                        [Formations](https://episen.u-pec.fr/formations)



                        ›


- 

                        [Technologies pour la Santé (ITS)](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)




[Formations](https://episen.u-pec.fr/formations)
[Technologies pour la Santé (ITS)](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

Les technologies du numérique et de l'intelligence artificielle au service de l'infrastructure dans la santé
CYCLE D'INGENIEUR EN 3 ANS (6 SEMESTRES UNIVERSITAIRES) Le diplôme d’ingénieur spécialisé en technologies pour la santé est un diplôme national de l’enseignement supérieur de niveau bac+5, habilité par la Commission des titres d'ingénieur (Cti).
[Télécharger la plaquette](https://episen.u-pec.fr/formations/brochure-episen-its-octobre-2024)
[> Les objectifs de la formation](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#objectifs)
[> Les compétences développées et l'insertion professionnelle](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#competences)
[> Pourquoi choisir cette formation ?](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#5raisons)
[> Le programme et les outils et équipements pédagogiques](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#programme)
[> Des expériences professionnelles riches pour une intégration réussie en entreprise](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#experiences)
[> Le passeport international pour valoriser vos expériences](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#passeport)
[> Les partenaires de la formation et le laboratoire associé](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#partenaires)
[> Les frais de scolarité](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#Frais)
[> Intégrer le cycle d'ingénieur Technologies pour la santé sur concours ou sur titre](https://episen.u-pec.fr/admissions/candidater-en-cycle-ingenieur)

### https://episen.u-pec.fr/formations/technologies-pour-la-sante-its LES OBJECTIFS DE LA FORMATION
[Cti](https://www.cti-commission.fr/)

### https://episen.u-pec.fr/formations/technologies-pour-la-sante-its POURQUOI CHOISIR CETTE FORMATION ?
- formation en groupes à effectifs restreints (24 élèves)
- suivi personnalisé des élèves et travaux pratiques en situation professionnelle
- projet de synthèse annuel mettant en application l’ensemble des compétences
- nombreux intervenants professionnels expérimentés (enseignants chercheurs 72% - professionnels 28%)
- une équipe d'enseignants experts en recherche collaborative
- une forte employabilité dans un univers technologique en pleine mutation
- formation ouverte sur les technologies émergentes et les outils intelligents appliqués à l’e-santé et à la santé connectée
- veille technologique pour la curiosité scientifique et l’accompagnement de l’apprenant au monde de la recherche scientifique

### https://episen.u-pec.fr/formations/technologies-pour-la-sante-its LE PROGRAMME ET LES OUTILS ET EQUIPEMENTS PÉDAGOGIQUES
Programme Technologies 46% Communication, langues vivantes et management 26% Fondamentaux en sciences pour l'ingénieur 14% Ouverture scientifique pluridisciplinaire et mise en situation 14% > Les enseignements sont proposés sous la forme de cours (70%) et de suivi de projets (30%). Outils Plateforme de E-Learning Préparation au TOEIC Equipements Plateformes de collecte de données patients et de géolocalisation Simulateur de données physiologiques Équipements de réalité virtuelle SmartPhones et terminaux mobiles Health Living Lab Infrastructure Cloud pour l’hébergement de données

### https://episen.u-pec.fr/formations/technologies-pour-la-sante-itsDES EXPERIENCES PROFESSIONNELLES RICHES POUR UNE INTÉGRATION RÉUSSIE EN ENTREPRISE
- 1re année : stage de découverte du monde professionnel de 6 semaines
- 2e année : stage de réalisation de 14 semaines à l’étranger
- 3e année : stage de fin d’études de 24 semaines

### https://episen.u-pec.fr/formations/technologies-pour-la-sante-its LE PASSEPORT INTERNATIONAL POUR VALORISER VOS EXPÉRIENCES
- séjours académiques ou professionnels à l’étranger.
- participation à l’ouverture internationale de l’école et de l’université.
- reconnaissance d’activités professionnelles ou de projets transnationaux.
- initiatives personnelles

Les frais de scolarité, sous statut étudiant, pour l'année universitaire 2025-2026 sont de 628 €.
- 
        Imprimer

- [Télécharger en PDF](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its?toPdf=true)
- 
        Partager

            Partager cette page

                    [Envoyer par email](https://episen.u-pec.fr/servlet/com.jsbsoft.jtf.core.SG?PROC=TRAITEMENT_ENVOI_AMI_FRONT&ACTION=ENVOYER&CODE=1457380695866&OBJET=article)

                        [Facebook](https://www.facebook.com/sharer/sharer.php?s=100&u=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

                        [X (Twitter)](https://twitter.com/intent/tweet?url=https%3A%2F%2Fepisen.u-pec.fr%2Fformations%2Ftechnologies-pour-la-sante-its&text=Dipl%C3%B4me+d%E2%80%99ing%C3%A9nieur+Technologies+pour+la+Sant%C3%A9+...)

                        [Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)



- 
                    [Envoyer par email](https://episen.u-pec.fr/servlet/com.jsbsoft.jtf.core.SG?PROC=TRAITEMENT_ENVOI_AMI_FRONT&ACTION=ENVOYER&CODE=1457380695866&OBJET=article)

- 
                        [Facebook](https://www.facebook.com/sharer/sharer.php?s=100&u=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

- 
                        [X (Twitter)](https://twitter.com/intent/tweet?url=https%3A%2F%2Fepisen.u-pec.fr%2Fformations%2Ftechnologies-pour-la-sante-its&text=Dipl%C3%B4me+d%E2%80%99ing%C3%A9nieur+Technologies+pour+la+Sant%C3%A9+...)

- 
                        [Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

- [Télécharger en PDF](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its?toPdf=true)
[Télécharger en PDF](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its?toPdf=true)
- 
                    [Envoyer par email](https://episen.u-pec.fr/servlet/com.jsbsoft.jtf.core.SG?PROC=TRAITEMENT_ENVOI_AMI_FRONT&ACTION=ENVOYER&CODE=1457380695866&OBJET=article)

- 
                        [Facebook](https://www.facebook.com/sharer/sharer.php?s=100&u=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

- 
                        [X (Twitter)](https://twitter.com/intent/tweet?url=https%3A%2F%2Fepisen.u-pec.fr%2Fformations%2Ftechnologies-pour-la-sante-its&text=Dipl%C3%B4me+d%E2%80%99ing%C3%A9nieur+Technologies+pour+la+Sant%C3%A9+...)

- 
                        [Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

[Envoyer par email](https://episen.u-pec.fr/servlet/com.jsbsoft.jtf.core.SG?PROC=TRAITEMENT_ENVOI_AMI_FRONT&ACTION=ENVOYER&CODE=1457380695866&OBJET=article)
[Facebook](https://www.facebook.com/sharer/sharer.php?s=100&u=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)
[X (Twitter)](https://twitter.com/intent/tweet?url=https%3A%2F%2Fepisen.u-pec.fr%2Fformations%2Ftechnologies-pour-la-sante-its&text=Dipl%C3%B4me+d%E2%80%99ing%C3%A9nieur+Technologies+pour+la+Sant%C3%A9+...)
[Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)
[Télécharger en PDF](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its?toPdf=true)

## Dans la même rubrique
- 
                        [Génie biomédical et santé (ISBS)](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs)

- 
                        [Technologies pour la Santé (ITS) - sous statut d'étudiant et d'apprenti](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

- 
                        [Systèmes d’Information (SI)](https://episen.u-pec.fr/formations/systemes-d-information-si)

- 
                        [Apprentissage](https://episen.u-pec.fr/formations/apprentissage)

[Génie biomédical et santé (ISBS)](https://episen.u-pec.fr/formations/biomedical-et-sante-isbs)
[Technologies pour la Santé (ITS) - sous statut d'étudiant et d'apprenti](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)
[Systèmes d’Information (SI)](https://episen.u-pec.fr/formations/systemes-d-information-si)
[Apprentissage](https://episen.u-pec.fr/formations/apprentissage)

## Pratique
- [Plans d'accès](https://episen.u-pec.fr/plans-d-acces)
- [Contact](https://episen.u-pec.fr/contact)
[Plans d'accès](https://episen.u-pec.fr/plans-d-acces)
[Contact](https://episen.u-pec.fr/contact)

## Accès rapides
- [eCampus](https://episen.u-pec.fr/e-campus)
- [EPREL (cours en ligne)](https://episen.u-pec.fr/eprel-cours-en-ligne)
- [Emplois du temps en ligne (ADE)](https://episen.u-pec.fr/emplois-du-temps-en-ligne-ade)
- [Messagerie étudiante](https://episen.u-pec.fr/messagerie-etudiante)
- [Intranet des personnels](https://episen.u-pec.fr/intranet-des-personnels)
- [Messagerie des personnels](https://episen.u-pec.fr/messagerie-des-personnels)
- [Office 365 EPISEN](https://episen.u-pec.fr/office-365-esipe)
[eCampus](https://episen.u-pec.fr/e-campus)
[EPREL (cours en ligne)](https://episen.u-pec.fr/eprel-cours-en-ligne)
[Emplois du temps en ligne (ADE)](https://episen.u-pec.fr/emplois-du-temps-en-ligne-ade)
[Messagerie étudiante](https://episen.u-pec.fr/messagerie-etudiante)
[Intranet des personnels](https://episen.u-pec.fr/intranet-des-personnels)
[Messagerie des personnels](https://episen.u-pec.fr/messagerie-des-personnels)
[Office 365 EPISEN](https://episen.u-pec.fr/office-365-esipe)

## Suivez l'UPEC
- [Mentions légales](https://episen.u-pec.fr/mentions-legales)



- [Plan du site](https://episen.u-pec.fr/plan-du-site)



- [Accessibilité des sites de l'UPEC : non conforme](https://episen.u-pec.fr/accessibilite-des-sites-de-lupec)



[Mentions légales](https://episen.u-pec.fr/mentions-legales)
[Plan du site](https://episen.u-pec.fr/plan-du-site)
[Accessibilité des sites de l'UPEC : non conforme](https://episen.u-pec.fr/accessibilite-des-sites-de-lupec)
[Haut de page](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its#body)
[https://episen.u-pec.fr/formations/technologies-pour-la-sante-its](https://episen.u-pec.fr/formations/technologies-pour-la-sante-its)

