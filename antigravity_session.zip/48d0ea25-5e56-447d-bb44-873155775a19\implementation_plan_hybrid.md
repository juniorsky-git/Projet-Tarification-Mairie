# Plan d'implémentation : Environnement Dev Hybrid (Docker + Local)

L'objectif est de sécuriser ton PostgreSQL dans Docker et de brancher ton Java local proprement sans toucher aux dossiers "Système" bloqués par la mairie.

## User Review Required

> [!IMPORTANT]
> **PostgreSQL (Docker)** : Nous n'utiliserons plus l'installation Windows qui a échoué. La base tournera dans un conteneur isolé.
> **Documents** : Tes données PostgreSQL seront stockées dans `C:\Users\stagedg2\Documents\Mairie_DB` pour être persistantes.
> **JDK** : Nous allons forcer l'usage du JDK Temurin trouvé dans ton profil utilisateur.

## Changements proposés

### [Component] Base de Données (PostgreSQL)

#### [NEW] [docker-compose.yml](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/docker-compose.yml)
- Utilisation de l'image `postgres:17-alpine` (légère et robuste).
- Configuration du port `5432`.
- Montage d'un volume vers `C:\Users\stagedg2\Documents\Mairie_DB`.

### [Component] Environnement Runtime

#### [NEW] [setup_env.ps1](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/setup_env.ps1)
Un script de confort pour :
1. Lancer `docker-compose up -d`.
2. Mettre à jour temporairement le `PATH` de la session actuelle pour utiliser le JDK 25 local.
3. Afficher un récapitulatif de santé de l'environnement.

## Plan de vérification

### Tests automatisés
1. `docker ps` : Vérifier que le conteneur `mairie-db` est bien EN COURS.
2. `java -version` : Vérifier que c'est bien la version 25 (Temurin) qui répond.
3. `ping` à l'intérieur du conteneur pour valider la communication.

### Vérification manuelle
- L'utilisateur lance `.\setup_env.ps1` et confirme que les versions affichées sont les bonnes.
