# Plan d'installation : Sécurisation de l'environnement Dev

Ce plan vise à installer tous les outils système indispensables (Database, Runtime, Linux, Containers) tant que tu possèdes les privilèges administrateur.

## Outils à installer / mettre à jour

### 1. Base de données : PostgreSQL
- **Action** : Installer PostgreSQL via Chocolatey.
- **Commande** : `choco install postgresql -y`
- **Vérification** : `psql --version`

### 2. Runtime Web : Node.js LTS
- **Action** : Installer la version Long Term Support (LTS).
- **Commande** : `choco install nodejs-lts -y`
- **Vérification** : `node -v`

### 3. Java Development Kit : Temurin 21
- **Action** : Installer le JDK 21 (Adoptium) comme JDK système par défaut.
- **Commande** : `choco install temurin21 -y`
- **Vérification** : `java -version` (doit afficher 21)

### 4. Linux : Ubuntu (WSL 2)
- **Action** : Installer la distribution Ubuntu standard. Docker est déjà là, mais il manque un environnement Linux pour le développement pur.
- **Commande** : `wsl --install -d Ubuntu`
- **Vérification** : `wsl --list --verbose`

## Risques et contraintes
- **Redémarrage** : Un redémarrage peut être nécessaire après l'installation de WSL Ubuntu.
- **Conflits de PATH** : On vérifiera après l'installation que les nouveaux outils sont bien prioritaires sur les anciennes versions.

## État actuel (Audit)
- **Docker Desktop** : Déjà installé et fonctionnel (Version 29.4.0).
- **WSL 2** : Activé.
- **Chocolatey** : Déjà présent (Version 2.7.1).
- **Node.js** : Version 20 présente dans `C:\tools`.
