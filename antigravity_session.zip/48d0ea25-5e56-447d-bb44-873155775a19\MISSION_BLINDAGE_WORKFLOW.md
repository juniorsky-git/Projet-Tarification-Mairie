# Journal Technique : Mission Blindage & Résilience
**Date :** 17 avril 2026  
**État :** Finalisé & Poussé  

## 📍 Épisode 1 : Le "Trou de Sécurité" (Audit)
### Le Problème (L'Erreur)
Lors du passage à la version 2.0 (multiversion), nous avons découvert une faille : la méthode `chargerGrilleStandard` acceptait les fichiers sans vérifier leur structure interne.  
*Risque :* Un agent de mairie charge un mauvais fichier Excel, le programme tente de lire des cases vides ou inexistantes -> Crash ou calculs erronés à zéro.

### La Réflexion (Workflow) : Physique vs Sémantique
Pour combler ce "trou", j'ai articulé ma réflexion sur deux types de validations :
1. **Validation Physique (L'enveloppe)** : Vérifier que le fichier "ressemble" à un Excel (Feuilles, lignes, en-têtes présents). C'est ce que font les Gardes 1, 2 et 3.
2. **Validation Sémantique (Le sens)** : Vérifier que le contenu est bien une grille tarifaire. On cherche les colonnes "pivots" comme `REPAS` et `ACCUEIL_JOURNEE`. C'est la **Garde 4**.

**Pourquoi c'est crucial ?** Sans la Garde 4, tu pouvais charger une liste de courses ou un planning d'entretien dans ton outil sans que le programme ne bronche. Désormais, l'outil "comprend" ce qu'il lit.

---

## 📍 Épisode 2 : Le Bug du "Hardcoding" (Environnement)
### Le Problème (L'Erreur)
Le script de construction `./build.ps1` utilisait un chemin vers le JDK Java 21 codé en dur. Une mise à jour de l'IDE a cassé le lien.

### La Réflexion (Workflow)
- **Mauvaise pratique** : Figer un chemin dépendant d'un tiers.
- **Solution Industrielle** : Utilisation de la détection dynamique par script PowerShell pour trouver automatiquement la version la plus récente de Java.

---

## 📍 Épisode 3 : Validation par Scénarios "Métier"
Le workflow s'est terminé par une simulation réelle d'un utilisateur agent de mairie :
1. **Tests d'intrusion** : Tenter de charger un PDF (Refusé ✅).
2. **Tests de structure** : Tenter de charger un Excel incomplet (Refusé par G4 ✅).
3. **Tests de précision** : Charger la Grille 2024 réelle (Validé ✅).

---
*Document finalisé consignant l'industrialisation de la sécurité du projet.*
