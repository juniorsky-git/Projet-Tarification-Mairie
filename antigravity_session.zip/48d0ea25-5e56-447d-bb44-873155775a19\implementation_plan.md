# Plan : Intégration des Données Réelles (CALC DEP(4).xlsx) dans l'API

## Objectif
Remplacer les données codées "en dur" dans l'API par les vraies dépenses extraites du fichier `CALC DEP(4).xlsx`, et exposer des endpoints REST pour les consulter.

## Données source identifiées

### Pôles de service
| Pôle | Dépenses totales | Coût unitaire |
|---|---|---|
| Restauration | 1 813 105,51 € | 11,48 €/repas |
| Accueil de Loisirs | 1 596 116,14 € | 5 868 €/enfant |
| Accueil Périscolaire | 658 856,78 € | 582,54 €/enfant |
| Etudes Surveillées | 58 598,14 € | 353,00 €/enfant |
| Espace Ados | 140 775,54 € | 1 268,25 €/enfant |
| Séjours | 107 127,71 € | 2 021,28 €/enfant |

### Catégories de charges (par pôle)
- Alimentation (Scolarest 6042 + Alimentation 60623)
- Fluides (Eau, Gaz, Électricité)
- Matériel et fournitures
- Sorties
- Transport
- Hébergement
- Personnel
- Autres

## Proposed Changes

---

### [Component] Modèles de données

#### [NEW] `DonneesBudgetaires.java`
Classe Java qui contient toutes les constantes extraites du fichier Excel :
- Dépenses totales par pôle
- Coûts par catégorie
- Coût unitaire par pôle

#### [NEW] `DepensePole.java`
Record Java représentant les dépenses d'un pôle avec toutes ses lignes de charge.

---

### [Component] API REST (`tarification-api/`)

#### [MODIFY] `PolesController.java` (ou équivalent)
Ajout des endpoints suivants :
- `GET /api/poles` → Retourne la liste des pôles avec les totaux de dépenses
- `GET /api/poles/{nom}/depenses` → Retourne le détail des charges d'un pôle
- `GET /api/poles/{nom}/cout-unitaire` → Retourne le coût unitaire d'un pôle

---

## GitHub Issue à créer

**Titre** : `feat: Intégrer les données réelles de dépenses (CALC DEP 4) dans l'API`

**Corps** :
```
## Contexte
Les données de dépenses sont actuellement codées en dur ou absentes de l'API.  
Le fichier CALC DEP(4).xlsx contient les données réelles 2025 ventilées par pôle.

## Tâches
- [ ] Créer la classe `DonneesBudgetaires.java` avec les constantes extraites
- [ ] Créer le record `DepensePole.java` (pôle + lignes de charges)
- [ ] Ajouter `GET /api/poles` dans le contrôleur
- [ ] Ajouter `GET /api/poles/{nom}/depenses`
- [ ] Ajouter `GET /api/poles/{nom}/cout-unitaire`
- [ ] Tester les endpoints avec curl ou Postman

## Données source
Fichier : `Donnees/Autres/CALC DEP(4).xlsx`, feuille `syntheses charges`
```

## Commandes Git à exécuter
```bash
git checkout -b feat/integration-donnees-reelles
# ... (faire les modifications)
git add src/
git commit -m "feat: ajout DonneesBudgetaires et endpoints /api/poles"
git push origin feat/integration-donnees-reelles
# Puis créer la Pull Request sur GitHub
```

## Plan de vérification
1. `curl http://localhost:8080/api/poles` → Retourne JSON avec 6 pôles
2. `curl http://localhost:8080/api/poles/Restauration/cout-unitaire` → Retourne `11.48`
3. Valider que les totaux correspondent au fichier Excel
