# Ajout des activités "Études surveillées" et "Espaces Ados"

Il s'agit d'intégrer de nouvelles activités pour les modules « Études surveillées » et « Espaces Ados » dans le système de tarification existant.

## Activités à ajouter
- **Études Surveillées** :
  1. Forfait mensuel (`etudes-forfait-mensuel`)
  2. 1/2 forfait pour les mois d'octobre, décembre, février, avril (`etudes-demi-forfait`)

- **Espaces Ados** :
  3. Vacances : Journée avec repas (`ados-vac-journee-repas`)
  4. Vacances : Journée sans repas (`ados-vac-journee-sans`)
  5. Vacances : 1/2 journée avec repas (`ados-vac-demi-repas`)
  6. Vacances : 1/2 journée sans repas (`ados-vac-demi-sans`)
  7. Sortie 1/2 journée Ile-de-France (`ados-sortie-demi`)
  8. Sortie journée ou stage (`ados-sortie-journee`)

## Modifications proposées

___

### `Tarif.java`

#### [MODIFY] [Tarif.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/src/Tarif.java)
- Ajout de 8 nouveaux attributs `double` pour stocker les prix de chacune de ces nouvelles activités.
- Ajout des "Getters" correspondants (ex: `getEtudesForfaitMensuel()`).
- Mise à jour du constructeur de classe. *Étant donné que le nombre d'arguments devient très grand, nous garderons le format actuel avec tous les arguments, ou nous pourrons envisager d'utiliser une `Map<String, Double>` (dictionnaire) si vous préférez une solution plus flexible.*

___

### `TarificationService.java`

#### [MODIFY] [TarificationService.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/src/TarificationService.java)
- Ajout de nouveaux `case` dans le `switch` de la méthode `obtenirPrix()` pour prendre en compte les chaînes de caractères associées (ex. : `"etudes-forfait-mensuel"`, `"ados-vac-journee-repas"`, etc.).

___

### `DonneesTarifs.java`

#### [MODIFY] [DonneesTarifs.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/src/DonneesTarifs.java)
- Mise à jour de la grille théorique en dur (`chargerTarifsReference`) pour ajouter ces nouveaux prix. **Cependant, ne connaissant pas vos tarifs chiffrés pour ces nouvelles activités, je mettrai `0.0` temporairement**, ou bien vous pourrez me donner les données.

___

### `Main.java`

#### [MODIFY] [Main.java](file:///c:/Users/stagedg2/Projet_mairie_outil_tarification/src/Main.java)
- Mettre à jour l'affichage informatif du `scanner` pour lister un aperçu des nouvelles activités à saisir pour l'utilisateur.

## Open Questions

> [!WARNING]
> 1. Avez-vous la grille des tarifs exacts pour ces 8 nouvelles activités afin que je les insère à la place des `0.0` dans le code ?
> 2. Le nombre d'activités grandit. Préférez-vous que je continue d'ajouter des variables simples comme `private double etudesForfaitMensuel;` ou bien souhaitez-vous que je transforme le code pour utiliser une structure de type "Dictionnaire" (`HashMap`) qui est plus professionnelle et évolutive ?

## Verification Plan
### Automated Tests
- Je lancerai la commande `javac -cp src src/*.java` pour m'assurer que toutes les modifications sont valides et que le projet compile.
### Manual Verification
- Exécution du `Main` pour simuler une demande de prix concernant l'espace ados et vérifier l'affichage effectif.
